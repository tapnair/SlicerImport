# SlicerImport
Framework to simplify the creation of Fusion 360 Addin

Documentation to come later. For now:



#Usage
Launch Command
Select any file in the output directory from Slicer
Set the material thickness
Set the spacing between sheets

OR

Select "tight pack" to remove the frames created by slicer and attempt to push the parts closer together


